from sklearn import svm
from sklearn import datasets
from sklearn import cross_validation
import numpy as np

def hehe(x):
	print("hello world")
	print(x)
	a = []
	a.append('8')
	print(a)
	a.append(['4'])
	print(a)
	a[1].append('5')
	print(a)

def sss():
	X = [[0, 0], [1, 1]]
	y = [0, 1]
	clf = svm.SVC()
	clf.fit(X, y)
	print(clf)
	print('predict')
	print(clf.predict([[1,9], [0,0]]))
	print(clf.support_vectors_)
	print(clf.support_)
	print(clf.n_support_)

def lala():
	iris = datasets.load_iris()
	print(iris)
	print(iris.data.shape, iris.target.shape)
	X_train, X_test, y_train, y_test = cross_validation.train_test_split(iris.data, iris.target, test_size=0.4, random_state=0)
	print(X_train.shape, y_train.shape)
	print(X_test.shape, y_test.shape)
	clf = svm.SVC(kernel='linear', C=1).fit(X_train, y_train)
	print(clf.score(X_test, y_test) )
	print(X_train, X_test, y_train, y_test)


def kfold():
	l = [0,0,0,0,1,1,1,2,2,2]
	skf = cross_validation.StratifiedKFold(l, 2)
	for train, test in skf:
		print("%s %s" % (train, test))

def main():
	#hehe("88")
	#sss()
	#lala()
	#kfold()
	tt = [[1,2,3],[1,2,3],[1,2,3],[1,2,3],[1,2,3]]
	print(len(tt))
if __name__ == "__main__":
	main()
