# -*- coding: utf-8 -*-

import os
import sgmllib, string
from nltk.tokenize import RegexpTokenizer
from nltk.stem.porter import PorterStemmer
from stop_words import get_stop_words
from gensim import corpora, models
from sklearn import svm
from sklearn import cross_validation
import numpy as np

# Global variable
document = []
orgainalTopic = []
docCount = -1;
features = []
dictionary = 0
topicDictionary = 0
trainFeature = []
testFeature = []


# Sgml parser
class ExtractDocument(sgmllib.SGMLParser):
	def __init__(self):
		sgmllib.SGMLParser.__init__(self)
		self.inTopic = 0
		self.inD = 0
		self.hasTopic = ''
		self.inBody = 0

	def start_reuters(self, attrs):
		global docCount
		self.hasTopic =  [v[0] for k, v in attrs if k == 'topics']
		if self.hasTopic == ['Y']:
			docCount = docCount + 1
			orgainalTopic.insert(docCount, [])
			document.insert(docCount, '')

	def end_reuters(self):
		self.hasTopic = ''

	def start_topics(self, attrs):
		if self.hasTopic == ['Y']:
			self.inTopic = 1
			

	def end_topics(self):
		self.inTopic = 0

	def start_d(self, attrs):
		self.inD = 1

	def end_d(self):
		self.inD = 0

	def start_body(self, attrs):
		self.inBody = 1;

	def end_body(self):
		self.inBody = 0;

	def handle_data(self, text):
		global document
		global orgainalTopic
		global docCount
		if self.hasTopic == ['Y'] and self.inTopic == 1 and self.inD == 1:
			orgainalTopic[docCount].append(text)
		elif self.hasTopic == ['Y'] and self.inBody == 1:
			s = document[docCount] + text
			document.pop(docCount)
			document.insert(docCount, s)

	################
	# Test
	#def unknown_starttag(self,tag,attrs):
	#	print('start tag:<'+tag+'>') 


# Loading corpus
def loadcorpus():
	global document
	global docCount
	global dictionary
	global orgainalTopic
	global topicDictionary

	corpusAddress = os.path.join('.', 'reuters21578')
	corpusFiles = [x for x in os.listdir(corpusAddress) if os.path.splitext(x)[1]=='.sgm']

	# 0. If there is something wrong
	if len(corpusFiles) == 0:
		print('Nothing in the corpus')
		return

	# 1. Show what in the folder 
	print('What we get are:')
	for corpusFile in corpusFiles:
		print(corpusFile + '\t')

	# 2. Load corpus into memory
	print('Loading...')
	# Store 22 files in there
	rawCorpus = []
	for corpusFile in corpusFiles:
		tempAddress = os.path.join(corpusAddress, corpusFile)
		with open(tempAddress, 'r', errors='ignore') as f:
			temptext = f.read()
			rawCorpus.append(temptext)
			#＃ TODO: do something replace this which is ugly
		print('Finish ' + corpusFile)
	print('Finish load raw corpus')

	# 2.5 Extract raw document from 
	print('Begin extract raw document')
	extracter = ExtractDocument()
	for rawText in rawCorpus:
		#＃ TODO: do something replace this which is ugly
		extracter.feed(rawText)

	extracter.close()
	print('Finish extracting documents')

	# Now we have all documents
	# 3. Preprocessing
	print('Begin preprocessing')

	tokenizer = RegexpTokenizer(r'\w+')
	en_stop = get_stop_words('en')
	p_stemmer = PorterStemmer()
	
	# There are many bugs in the corpus, for example: it said one document has topics but actually it's not and even this document is not aviliable.
	# So, clean first
	docIndex = 0
	tempIndex = 0;
	tempDocuments = []
	tempTopics = []
	while docIndex < len(document):
		if document[docIndex] != None and document[docIndex] != '' and len(orgainalTopic[docIndex]) == 1:
			tempDocuments.insert(tempIndex, document[docIndex])
			tempTopics.insert(tempIndex, orgainalTopic[docIndex])
			tempIndex = tempIndex + 1
		docIndex = docIndex + 1
	document = tempDocuments
	orgainalTopic = tempTopics
	# Fiish cleaning
	
	docIndex = 0
	while docIndex < len(document):
		# 0. Lower case
		document[docIndex] = document[docIndex].lower()
		# 1. Tokenization
		document[docIndex] = tokenizer.tokenize(document[docIndex])
		# 2. Stop words
		document[docIndex] = [i for i in document[docIndex] if not i in en_stop]
		# 3. Stemming
		document[docIndex] = [p_stemmer.stem(i) for i in document[docIndex]]
		# 4. Finish
		docIndex = docIndex + 1
		#＃ TODO: do something replace this which is ugly
	print('Just wait a second...')
	dictionary = corpora.Dictionary(document)
	topicDictionary = corpora.Dictionary(orgainalTopic)
	corpus = [dictionary.doc2bow(doc) for doc in document]
	document = corpus
	topicList = [topicDictionary.doc2bow(topic)[0][0] for topic in orgainalTopic]
	orgainalTopic = topicList
	print('Finish preprocessing')
	 

# Getting features with LDA
def getFeature(topic, train, test):
	global document
	global dictionary
	global trainFeature
	global testFeature

	print('Begin getting features')

	trainFeature = []
	testFeature = []

	# Get training set and test set
	tmpTrainDocument = [document[index] for index in train]
	temTestDocument = [document[index] for index in test]

	# Get model by training set
	ldamodel = models.ldamodel.LdaModel(tmpTrainDocument, num_topics=topic, id2word = dictionary, passes=20)
	
	# Get features for training
	topicIndex = 0
	distrIndex = 0
	for doc in tmpTrainDocument:
		trainFeature.append([])
		distr = ldamodel[doc]
		while topicIndex < topic:
			if topicIndex == distr[distrIndex][0]:
				trainFeature[len(trainFeature) - 1].append(distr[distrIndex][1])
				if distrIndex < len(distr) - 1:
					distrIndex = distrIndex + 1
			else:
				trainFeature[len(trainFeature) - 1].append(0)
			topicIndex = topicIndex + 1
		topicIndex = 0
		distrIndex = 0

	# Get features for testing
	topicIndex = 0
	distrIndex = 0
	for doc in temTestDocument:
		testFeature.append([])
		distr = ldamodel[doc]
		while topicIndex < topic:
			if topicIndex == distr[distrIndex][0]:
				testFeature[len(testFeature) - 1].append(distr[distrIndex][1])
				if distrIndex < len(distr) - 1:
					distrIndex = distrIndex + 1
			else:
				testFeature[len(testFeature) - 1].append(0)
			topicIndex = topicIndex + 1
		topicIndex = 0
		distrIndex = 0

	print('Finished getting features')

# Text categorization
def createCLFbyLDA(train, test):
	print('Build classifier with LDA features')
	y = [orgainalTopic[index] for index in train]
	clf = svm.SVC(kernel='linear', C=1).fit(trainFeature, y)
	tmpTestTopic = [orgainalTopic[index] for index in test]
	print('accury = %.4f' % (clf.score(testFeature, tmpTestTopic)))

'''
	predictTopic = clf.predict(testFeature)
	wrong = 0
	right = 0
	
	for (predict, fact) in zip(predictTopic, tmpTestTopic):
		if predict == fact:
			right = right + 1
		else:
			wrong = wrong + 1
	print('right = %s , wrong = %s, precision = %.2f' %(right, wrong, right / (right + wrong)))

	################# Test
	#print('predict', clf.predict([features[90]]))
	#print('actually', orgainalTopic[90])
'''

def createCLFbyWordBag(train, test):
	print('Build classifier with vector space model')
	X_test = []
	y_test = []
	X_train = []
	y_train = []
	# 1. Create features 
	for trainDocIndex in train:
		y_train.append(orgainalTopic[trainDocIndex])
		tmp = []
		wordIndex = 0
		wordIndex2 = 0
		while wordIndex < len(dictionary):
			if wordIndex == document[trainDocIndex][wordIndex2][0]:
				tmp.append(document[trainDocIndex][wordIndex2][1])
				if wordIndex2 < len(document[trainDocIndex]) - 1:
					wordIndex2 = wordIndex2 + 1
			else:
				tmp.append(0)
			wordIndex = wordIndex + 1
		X_train.append(tmp)
	for testDocIndex in test:
		y_test.append(orgainalTopic[testDocIndex])
		tmp = []
		wordIndex = 0
		wordIndex2 = 0
		while wordIndex < len(dictionary):
			if wordIndex == document[testDocIndex][wordIndex2][0]:
				tmp.append(document[testDocIndex][wordIndex2][1])
				if wordIndex2 < len(document[testDocIndex]) - 1:
					wordIndex2 = wordIndex2 + 1
			else:
				tmp.append(0)
			wordIndex = wordIndex + 1
		X_test.append(tmp)

	clf = svm.SVC(kernel='linear', C=1).fit(X_train, y_train)
	print('accury = %.4f' % (clf.score(X_test, y_test)))

def kfold(k, topic):
	skf = cross_validation.StratifiedKFold(orgainalTopic, k)
	
	print('use LDA to produce features, k = %s, topic number = %s' % (k, topic))
	step = 1
	for train, test in skf:
		print('Step %s:' %(step))
		step = step + 1
		getFeature(topic, train, test)
		createCLFbyLDA(train, test)
	
	print('use vector space model to produce features, k = %s' % (k))
	step = 1
	for train, test in skf:
		print('Step %s:' %(step))
		step = step + 1
		createCLFbyWordBag(train, test)

def main():
	# First, load all corpus
	loadcorpus()
	#kfold(10, 60)
	print(len(document))
	print(len(dictionary))

if __name__ == "__main__":
	main()
