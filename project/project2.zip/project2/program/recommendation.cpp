#include <iostream>
#include <string>
#include <cstring>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <vector>
#include <algorithm>

using namespace std;
int trainCount = 0;
int testCount = 0;
string sourceLocation;
int function = 0;
int user = -1;
int object = -1;
int ** train;
int ** test;
double * vectorSpaceSimilarity;
double ** correlationItemSimilarity;
double * IUF;

int errNotify(string err){
	cout << "***************************************************************************************" << endl;
	cout << "ERROR: " << err << endl;
	cout << "***************************************************************************************" << endl;
	return 0; 
}

double timer(clock_t start){
	clock_t finish = clock();
	double totaltime = (double)(finish - start)/CLOCKS_PER_SEC;
	return totaltime;
}

bool bigger_second(const pair<int, double> &a, const pair<int, double> &b){
	return a.second > b.second;
}

double IUFCompute(double * &IUF, int ** &train){
	int i, j;
	int itemCount = 0;
	IUF = (double *)calloc(1000, sizeof(double));
	for(i = 0; i < 1000; i++){
		for(j = 0; j < trainCount; j++){
			if(train[j][i] != 0)
				itemCount++;
		}
		if(itemCount != 0){
			IUF[i] = log(trainCount / itemCount);
		}else{
			IUF[i] = 0;
		}
		itemCount = 0;
	}
}

double IUFMemoryBasedPrediction(int * &user, int ** &dataSet, double * &similarity, int item){
	int i,j;
	double averageUserRate, minus, subResult, normalization;
	int userRateCount, dataRateCount;
	averageUserRate = userRateCount = subResult = dataRateCount = minus = normalization = 0;
	for(i = 0; i < 1000; i++){
		if(i == item || user[i] == 0)
			continue;
		averageUserRate += user[i];
		userRateCount ++ ;
	}
	averageUserRate = averageUserRate / userRateCount;

	for(i = 0; i < trainCount; i++){
		for(j = 0; j < 1000; j++){
			if(dataSet[i][j] != 0){
				minus += dataSet[i][j];
				dataRateCount ++;
			}
		}
		if(dataSet[i][item] != 0){
			subResult += similarity[i] * (dataSet[i][item] - minus / dataRateCount);
		 	normalization += fabs(similarity[i]);
		}
		minus = dataRateCount = 0;
	}
	if(normalization != 0){
		return averageUserRate + subResult / normalization;
	}else{
		return averageUserRate;
	}
	
}

int IUFMemoryBasedVectorSpaceSimilarity(int * &user, int ** &dataSet, double * &result, int item){
	result = (double*)calloc(trainCount, sizeof(double));
	int i, j, k;
	int multiplication, userRate, dataRate;
	multiplication = userRate = dataRate = 0;
	for(i = 0; i < trainCount; i++){
		for(j = 0; j < 1000; j ++){
			if(j == item){
				continue;
			}
			multiplication += user[j] * IUF[j] * dataSet[i][j] * IUF[j];
			userRate += user[j] * user[j] * IUF[j] * IUF[j];
			dataRate += dataSet[i][j] * dataSet[i][j] * IUF[j] * IUF[j];
		}
		result[i] = multiplication / (sqrt(userRate) * sqrt(dataRate));
		multiplication = userRate = dataRate = 0;
	}
	return 0;
}

double IUFMemoryBasedEvaluation(int ** &test, int ** &dataSet){
	clock_t start;
	int i, j, k, itemCount, itemCountAll;
	itemCount = itemCountAll = 0;
	double predictRate, wrongRate, wrongRateAll;
	predictRate = wrongRate = wrongRateAll = 0;
	for(i = 0; i < testCount; i ++){
		for(j = 0; j < 1000; j ++){
			if(test[i][j] == 0){
				continue;
			}else{
				start = clock();
				itemCount++;
				IUFMemoryBasedVectorSpaceSimilarity(test[i], dataSet, vectorSpaceSimilarity, j);
				predictRate = IUFMemoryBasedPrediction(test[i], dataSet, vectorSpaceSimilarity, j);
				wrongRate += fabs(predictRate - test[i][j]);
				/*
				cout << "test " << i << ", item " << j << ": real rate is " << test[i][j]
					 << ", prediction is " << predictRate << ", use time " <<  timer(start) << "s" <<endl;
				*/
				free(vectorSpaceSimilarity);
			}
		}
		cout << "test " << itemCount << " item for this user and absolute error is " << wrongRate
			 << ", average absolute error is " << wrongRate / itemCount << endl;
		wrongRateAll += wrongRate;
		itemCountAll += itemCount;
		wrongRate = itemCount = 0;
	}
	cout << "totally, test " << testCount << " users and " << itemCountAll << " items, all absolute error is " 
		 << wrongRateAll << " and average absolute error is " << wrongRateAll / itemCountAll << endl;
}

double itemBasedPrediction(int item){
	clock_t start;
	int i, j;
	double subResult, normalization, predictRate;
	subResult = normalization = predictRate = 0;
	vector<pair<int, double> > similarity;
	for(i = 0; i < 1000; i++){
		if(test[0][i] == 0){
			continue;
		}
		if(i > item){
			similarity.push_back(make_pair(i, correlationItemSimilarity[item][i]));
		}else{
			similarity.push_back(make_pair(i, correlationItemSimilarity[i][item]));
		}
		
	}
	sort(similarity.begin(), similarity.end(), bigger_second);
	for(int l = 0; l < 10 && l < similarity.size(); l++){
		subResult += similarity[l].second * test[0][similarity[l].first];
		normalization += fabs(similarity[l].second);
		//cout << " " << similarity[l].first << " " << similarity[l].second << endl;
	}
	predictRate = subResult / normalization;
	similarity.clear();
	return predictRate;
}

double itemBasedEvaluation(int ** &test){
	clock_t start;
	int i, j, k, l, itemCount, itemCountAll;
	double subResult, normalization, predictRate, wrongRate, wrongRateAll;
	wrongRateAll = itemCountAll = 0;
	for(i = 0; i < testCount; i++){
		itemCount = 0;
		wrongRate = 0;
		for(j = 0; j < 1000; j++){
			if(test[i][j] == 0){
				continue;
			}else{
				start = clock();
				itemCount++;
				subResult = normalization = 0;
				vector<pair<int, double> > similarity;
				for(k = 0; k < 1000; k++){
					if(test[i][k] == 0){
						continue;
					}
					if(k > j){
						similarity.push_back(make_pair<int, double>(k, correlationItemSimilarity[j][k]));
					}else{
						similarity.push_back(make_pair<int, double>(k, correlationItemSimilarity[k][j]));
					}
					//cout << similarity[k].first << " " << similarity[k].second << endl;
				}
				sort(similarity.begin(), similarity.end(), bigger_second);
				for(l = 0; l < 15 && l < similarity.size(); l++){
					subResult += similarity[l].second * test[i][similarity[l].first];
					normalization += fabs(similarity[l].second);
					//cout << " " << similarity[l].first << " " << similarity[l].second << endl;
					//cout << test[i][similarity[l].first] << endl;
				}
				predictRate = subResult / normalization;
				wrongRate += fabs(predictRate - test[i][j]);
				/*
				cout << "test " << i << ", item " << j << ": real rate is " << test[i][j]
					 << ", prediction is " << predictRate << " ,absolute error is " << fabs(predictRate - test[i][j]) 
					 << " ,use time: " << timer(start) << "s" << endl;
					 */
				similarity.clear();
			}
		}
		cout << "test " << itemCount << " item for this user and absolute error is " << wrongRate
			 << ", average absolute error is " << wrongRate / itemCount << endl;
		itemCountAll += itemCount;
		wrongRateAll += wrongRate;
	}
	cout << "totally, test " << testCount << " user and " << itemCountAll << " item, all absolute error is "
		 << wrongRateAll << ", and average absolute error is " << wrongRateAll / itemCountAll << endl;
}

double itemBasedCorrelationBasedSimilarity(int ** &train, double ** &correlationItemSimilarity){
	cout << "start calculation of correlation-based similarity" << endl;
	clock_t start = clock();
	int i, j, k, Ri, Rj, itemCount;
	double subResult, normalization1, normalization2;
	Ri = Rj = itemCount = subResult = normalization1 = normalization2 = 0;
	correlationItemSimilarity = (double **)calloc(1000, sizeof(double *));
	for(i = 0; i < 1000; i++){
		correlationItemSimilarity[i] = (double *)calloc(1000, sizeof(double));
		for(j = 0; j < 1000; j++){
			if(j < i){
				continue;
			}else if(j == i){
				correlationItemSimilarity[i][j] = 1;
			}else{
				for(k = 0; k < trainCount; k++){
					if(train[k][i] == 0 || train[k][j] == 0){
						continue;
					}
					itemCount ++ ;
					Ri += train[k][i];
					Rj += train[k][j];
				}
				if(itemCount != 0){
					Ri = Ri / itemCount;
					Rj = Rj / itemCount;
					for(k = 0; k < trainCount; k++){
						if(train[k][i] == 0 || train[k][j] == 0){
							continue;
						}
						subResult += (train[k][i] - Ri) * (train[k][j] - Rj);
						normalization1 += (train[k][i] - Ri) * (train[k][i] - Ri);
						normalization2 += (train[k][j] - Rj) * (train[k][j] - Rj);
					}
					if(subResult != 0)
						correlationItemSimilarity[i][j] = subResult / (sqrt(normalization1) * sqrt(normalization2));
					else
						correlationItemSimilarity[i][j] = 1;
				}else{
					correlationItemSimilarity[i][j] = 0;
				}
				itemCount = Ri = Rj = subResult = normalization1 = normalization2 = 0;
			}
			//cout << i << " " << j << " " << correlationItemSimilarity[i][j] << endl;
		}
	}
	cout << "finish similarity calculation, used time:" << timer(start) << "s" << endl;
}

double memoryBasedPrediction(int * &user, int ** &dataSet, double * &similarity, int item){
	int i,j;
	double averageUserRate, minus, subResult, normalization;
	int userRateCount, dataRateCount;
	averageUserRate = userRateCount = subResult = dataRateCount = minus = normalization = 0;
	for(i = 0; i < 1000; i++){
		if(i == item || user[i] == 0)
			continue;
		averageUserRate += user[i];
		userRateCount ++ ;
	}
	averageUserRate = averageUserRate / userRateCount;

	for(i = 0; i < trainCount; i++){
		for(j = 0; j < 1000; j++){
			if(dataSet[i][j] != 0){ //================
				minus += dataSet[i][j];
				dataRateCount ++;
			}
		}
		//cout << dataSet[i][item] << " " << minus/dataRateCount << endl; 
		if(dataSet[i][item] != 0){
			subResult += similarity[i] * (dataSet[i][item] - minus / dataRateCount);
			normalization += fabs(similarity[i]);
		}
		minus = dataRateCount = 0;
	}
	if(normalization != 0){
		return averageUserRate + subResult / normalization;
	}else{
		return averageUserRate;
	}
	
}

int memoryBasedVectorSpaceSimilarity(int * &user, int ** &dataSet, double * &result, int item){
	result = (double*)calloc(trainCount, sizeof(double));
	int i,j;
	int multiplication, userRate, dataRate;
	multiplication = userRate = dataRate = 0;
	for(i = 0; i < trainCount; i++){
		for(j = 0; j < 1000; j ++){
			if(j == item){
				continue;
			}
			multiplication += user[j] * dataSet[i][j];
			userRate += user[j] * user[j];
			dataRate += dataSet[i][j] * dataSet[i][j];
		}
		result[i] = multiplication / (sqrt(userRate) * sqrt(dataRate));
		//if below is no exist, vector similarity be will wrong, but the result will be better.
		//multiplication = userRate = dataRate = 0;
	}
	return 0;
}

double memoryBasedEvaluation(int ** &test, int ** &dataSet){
	clock_t start;
	int i, j, k, itemCount, itemCountAll;
	itemCount = itemCountAll = 0;
	double predictRate, wrongRate, wrongRateAll;
	predictRate = wrongRate = wrongRateAll = 0;
	for(i = 0; i < testCount; i ++){
		for(j = 0; j < 1000; j ++){
			if(test[i][j] == 0){
				continue;
			}else{
				start = clock();
				itemCount++;
				memoryBasedVectorSpaceSimilarity(test[i], dataSet, vectorSpaceSimilarity, j);
				predictRate = memoryBasedPrediction(test[i], dataSet, vectorSpaceSimilarity, j);
				wrongRate += fabs(predictRate - test[i][j]);
				/*
				cout << "test " << i << ", item " << j << ": real rate is " << test[i][j]
					 << ", prediction is " << predictRate << ", use time " <<  timer(start) << "s" <<endl;
				*/
				free(vectorSpaceSimilarity);
			}
		}
		cout << "test " << itemCount << " item for this user and absolute error is " << wrongRate
			 << ", average absolute error is " << wrongRate / itemCount << endl;
		wrongRateAll += wrongRate;
		itemCountAll += itemCount;
		wrongRate = itemCount = 0;
	}
	cout << "totally, test " << testCount << " users and " << itemCountAll << " items, all absolute error is " 
		 << wrongRateAll << " and average absolute error is " << wrongRateAll / itemCountAll << endl;
}

int loadData(int ** &train, int ** &test, string adr, int testCount){
	trainCount = 200 - testCount;
	train = (int **)calloc(trainCount, sizeof(int *));
	test = (int **)calloc(testCount, sizeof(int *));
	FILE * fp = fopen(adr.c_str(), "r");
	int tmp1 = 200/testCount;
	int i, j;
	int testIndex, trainIndex;
	testIndex = trainIndex = 0;
	for(i = 0; i < 200; i ++){
		if(i % tmp1 == 0 && testIndex < testCount){
			test[testIndex] = (int *)calloc(1000, sizeof(int));
			for(j = 0; j <1000; j ++){
				if(fscanf(fp, "%d", &test[testIndex][j]) != 1){
					errNotify("can't read source file");
					cout << i << " "<< j << endl;
					return -1;
				}
			}
			testIndex++;
		}else{
			train[trainIndex] = (int *)calloc(1000, sizeof(int));
			for(j = 0; j <1000; j ++){
				if(fscanf(fp, "%d", &train[trainIndex][j]) != 1){
					errNotify("can't read source file");
					cout << i << " "<< j << endl;
					return -1;
				}
			}
			trainIndex++;
		}
	}
	return 0;
}

int loadData2(int ** &train, int ** &test, string adr, int user){
	trainCount = 199;
	testCount = 1;
	train = (int **)calloc(199, sizeof(int *));
	test = (int **)calloc(1, sizeof(int *));
	FILE * fp = fopen(adr.c_str(), "r");
	int i, j;
	int trainIndex = 0;
	for(i = 0; i < 200; i ++){
		if(i == user){
			test[0] = (int *)calloc(1000, sizeof(int));
			for(j = 0; j <1000; j ++){
				if(fscanf(fp, "%d", &test[0][j]) != 1){
					errNotify("can't read source file");
					cout << i << " "<< j << endl;
					return -1;
				}
			}
		}else{
			train[trainIndex] = (int *)calloc(1000, sizeof(int));
			for(j = 0; j <1000; j ++){
				if(fscanf(fp, "%d", &train[trainIndex][j]) != 1){
					errNotify("can't read source file");
					cout << i << " "<< j << endl;
					return -1;
				}
			}
			trainIndex++;
		}
	}
	return 0;
}



//need more infomation about my own algorithm
int usage(){
	cout<< "Information Retrieval Project2" << endl  
		<< "Movie recommendation system usage:" << endl
		<< "parameters:" << endl
		<< "command\tparameter\t\texplain" << endl
		<< "-s\tsourcefile\t\tlocation of sourcefile" << endl
		<< "-c\tcount of test\t\tthe number of test" << endl
		<< "-f\tfunction\t\tThis is not required. If not input, program will use all three algorithms. Function is the algorithm want to use, \n\t\t\t\t1 memory-based; 2 model-based; 3 my own algorithm：memory-based with Inverse User Frequency" << endl
		<< "-u\tuser\t\t\tThis is not required. If you want to predict one item rate of one user. If you input this, -c will be unavilable." << endl
		<< "-o\titem\t\t\tThis is not required. If you want to predict one item rate of one user. If you input this, -c will be unavilable." << endl
		<< "example:" << endl
		<< "recommendation -s train.txt -c 10 -f 1" << endl
		<< "recommendation -s train.txt -c 10 -f 1 -u 10 -o 100" << endl;
}

int getParameters(int argc, char ** argv){
	int flagS = 0;
	int flagC = 0;

	if(argc < 5 || argc % 2 == 0){
		usage();
		errNotify("Please input parameters correctly");
		return -1;
	}

	int i;
	for(i = 1; i < argc; i++){
		if(strcmp(argv[i], "-s") == 0){
			string tmp(argv[i + 1]);
			sourceLocation = tmp;
			flagS = 1;
		}
		if(strcmp(argv[i], "-c") == 0){
			testCount = atoi(argv[i + 1]);
			flagC = 1;
		}
		if(strcmp(argv[i], "-f") == 0){
			function = atoi(argv[i + 1]);
		}
		if(strcmp(argv[i], "-u") == 0){
			user = atoi(argv[i + 1]);
		}
		if(strcmp(argv[i], "-o") == 0){
			object = atoi(argv[i + 1]);
		}
	}
	if(flagS == 0){
		errNotify("please input the location of source file");
		return -1;
	}
	if(flagC == 0){
		errNotify("please input the number of test case");
		return -1;
	}
	switch(function){
		case 0:
		cout << "you didn't input what function you want. program will run with all three algorithms" << endl;
		break;
		case 1:
		cout << "memory-based algorithm will be used" << endl;
		break;
		case 2:
		cout << "model-based algorithm will be used" << endl;
		break;
		case 3:
		cout << "my own algorithm will be used" << endl;
		break;
	}
	return 0;
}



int main(int argc, char ** argv){
	cout << "start!" << endl;
	clock_t start, last;
	start = last = clock();

	if(getParameters(argc, argv) != 0){
		errNotify("There is a fatal error and program exits now");
		return -1;
	}
	if(user != -1 && object != -1){
		if(loadData2(train, test, sourceLocation, user) != 0){
			errNotify("There is a fatal error and program exits now");
			return -1;
		}
	}else{
		if(loadData(train, test, sourceLocation, testCount) != 0){
			errNotify("There is a fatal error and program exits now");
			return -1;
		}
	}
	
	
	last = clock();
	cout << "finish reading training data, use " << timer(last) << "s, totally used " << timer(start) << "s" << endl;

	if(function == 0 || function == 1){
		cout << "start memory-based algorithm" << endl;
		if(user != -1 && object != -1){
			memoryBasedVectorSpaceSimilarity(test[0], train, vectorSpaceSimilarity, object);
			double predictRate = memoryBasedPrediction(test[0], train, vectorSpaceSimilarity, object);
			cout << "user " << user  << ", item " << object << " : " << predictRate << endl;
			cout << "finish prediction , use " << timer(last) << "s, totally used " << timer(start) << "s" << endl;
			free(vectorSpaceSimilarity);
		}else{
			memoryBasedEvaluation(test, train);
			cout << "finish prediction and evaluation, use " << timer(last) << "s, totally used " << timer(start) << "s" << endl;
		}
		last = clock();
	}

	if(function == 0 || function == 2){
		cout << "start item-based algorithm" << endl;
		if(user != -1 && object != -1){
			itemBasedCorrelationBasedSimilarity(train, correlationItemSimilarity);
			double predictRate = itemBasedPrediction(object);
			cout << "user " << user  << ", item " << object << " : " << predictRate << endl;
			cout << "finish prediction, use " << timer(last) << "s, totally used " << timer(start) << "s" << endl;
			
		}else{
			itemBasedCorrelationBasedSimilarity(train, correlationItemSimilarity);
			itemBasedEvaluation(test);
			cout << "finish prediction and evaluation, use " << timer(last) << "s, totally used " << timer(start) << "s" << endl;
			
		}
		for(int hehe = 0; hehe < 1000; hehe ++){
			free(correlationItemSimilarity[hehe]);
		}
		free(correlationItemSimilarity);
		last = clock();
	}

	if(function == 0 || function == 3){
		cout << "start memory-based algorithm improved with Inverse User Frequency" << endl;
		IUFCompute(IUF, train);
		if(user != -1 && object != -1){
			IUFMemoryBasedVectorSpaceSimilarity(test[0], train, vectorSpaceSimilarity, object);
			double predictRate = IUFMemoryBasedPrediction(test[0], train, vectorSpaceSimilarity, object);
			cout << "user " << user  << ", item " << object << " : " << predictRate << endl;
			cout << "finish prediction , use " << timer(last) << "s, totally used " << timer(start) << "s" << endl;
			free(vectorSpaceSimilarity);
		}else{
			IUFMemoryBasedEvaluation(test, train);
			cout << "finish prediction and evaluation, use " << timer(last) << "s, totally used " << timer(start) << "s" << endl;
		}
		free(IUF);
		last = clock();
	}

	return 0;
}