#!/bin/bash
 
cd ../myRetrieval/

./myRetrieval -k 10 -c 0.1 -o 1 -q final exam
#sleep 50
./myRetrieval -k 10 -c 0.1 -o 2 -q tcp
sleep 50
./myRetrieval -k 10 -c 0.1 -o 3 -q computer system
sleep 50
./myRetrieval -k 10 -c 0.1 -o 4 -q network paper
sleep 50
./myRetrieval -k 10 -c 0.1 -o 5 -q spring break
sleep 50

./myRetrieval -k 50 -c 0.1 -o 1 -q final exam
sleep 50
./myRetrieval -k 50 -c 0.1 -o 2 -q tcp
sleep 50
./myRetrieval -k 50 -c 0.1 -o 3 -q computer system
sleep 50
./myRetrieval -k 50 -c 0.1 -o 4 -q network paper
sleep 50
./myRetrieval -k 50 -c 0.1 -o 5 -q spring break
sleep 50

./myRetrieval -k 100 -c 0.1 -o 1 -q final exam
sleep 50
./myRetrieval -k 100 -c 0.1 -o 2 -q tcp
sleep 50
./myRetrieval -k 100 -c 0.1 -o 3 -q computer system
sleep 50
./myRetrieval -k 100 -c 0.1 -o 4 -q network paper
sleep 50
./myRetrieval -k 100 -c 0.1 -o 5 -q spring break
sleep 50

./myRetrieval -k 150 -c 0.1 -o 1 -q final exam
sleep 50
./myRetrieval -k 150 -c 0.1 -o 2 -q tcp
sleep 50
./myRetrieval -k 150 -c 0.1 -o 3 -q computer system
sleep 50
./myRetrieval -k 150 -c 0.1 -o 4 -q network paper
sleep 50
./myRetrieval -k 150 -c 0.1 -o 5 -q spring break
sleep 50

./myRetrieval -k 200 -c 0.1 -o 1 -q final exam
sleep 50
./myRetrieval -k 200 -c 0.1 -o 2 -q tcp
sleep 50
./myRetrieval -k 200 -c 0.1 -o 3 -q computer system
sleep 50
./myRetrieval -k 200 -c 0.1 -o 4 -q network paper
sleep 50
./myRetrieval -k 200 -c 0.1 -o 5 -q spring break
sleep 50



cd ../myEvaluation/

./myEvaluation 10
sleep 3

./myEvaluation 50
sleep 3

./myEvaluation 100
sleep 3

./myEvaluation 150
sleep 3

./myEvaluation 200
sleep 3

echo "done!"

