#!/bin/bash
#evaluation



cd ../myEvaluation

./myEvaluation 200

./myEvaluation 250

./myEvaluation 300

./myEvaluation 350


echo "done!"

