#!/bin/bash
 



cd ../myEvaluation/

./myEvaluation 10

./myEvaluation 50

./myEvaluation 100

./myEvaluation 150

./myEvaluation 200

./myEvaluation 250

./myEvaluation 300

./myEvaluation 350

./myEvaluation 400

./myEvaluation 450

./myEvaluation 500

./myEvaluation 550

./myEvaluation 600

./myEvaluation 650

./myEvaluation 700

./myEvaluation 750

./myEvaluation 800

./myEvaluation 850

./myEvaluation 900

./myEvaluation 950

./myEvaluation 1000


echo "done!"

