#!/bin/bash
 
cd ../myRetrieval/

./myRetrieval -k 10 -c 0.1 -o 1 -q final exam

./myRetrieval -k 10 -c 0.1 -o 2 -q tcp

./myRetrieval -k 10 -c 0.1 -o 3 -q computer system

./myRetrieval -k 10 -c 0.1 -o 4 -q network paper

./myRetrieval -k 10 -c 0.1 -o 5 -q spring break

./myRetrieval -k 10 -c 0.1 -o 6 -q software major

./myRetrieval -k 10 -c 0.1 -o 7 -q team work

./myRetrieval -k 10 -c 0.1 -o 8 -q group learn

./myRetrieval -k 10 -c 0.1 -o 9 -q public sever

./myRetrieval -k 10 -c 0.1 -o 10 -q america law

./myRetrieval -k 10 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 10 -c 0.1 -o 12 -q rsa

./myRetrieval -k 10 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 10 -c 0.1 -o 14 -q major

./myRetrieval -k 10 -c 0.1 -o 15 -q phd project

./myRetrieval -k 10 -c 0.1 -o 16 -q homework

./myRetrieval -k 10 -c 0.1 -o 17 -q fee due

./myRetrieval -k 10 -c 0.1 -o 18 -q drop class

./myRetrieval -k 10 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 10 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 50 -c 0.1 -o 1 -q final exam

./myRetrieval -k 50 -c 0.1 -o 2 -q tcp

./myRetrieval -k 50 -c 0.1 -o 3 -q computer system

./myRetrieval -k 50 -c 0.1 -o 4 -q network paper

./myRetrieval -k 50 -c 0.1 -o 5 -q spring break

./myRetrieval -k 50 -c 0.1 -o 6 -q software major

./myRetrieval -k 50 -c 0.1 -o 7 -q team work

./myRetrieval -k 50 -c 0.1 -o 8 -q group learn

./myRetrieval -k 50 -c 0.1 -o 9 -q public sever

./myRetrieval -k 50 -c 0.1 -o 10 -q america law

./myRetrieval -k 50 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 50 -c 0.1 -o 12 -q rsa

./myRetrieval -k 50 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 50 -c 0.1 -o 14 -q major

./myRetrieval -k 50 -c 0.1 -o 15 -q phd project

./myRetrieval -k 50 -c 0.1 -o 16 -q homework

./myRetrieval -k 50 -c 0.1 -o 17 -q fee due

./myRetrieval -k 50 -c 0.1 -o 18 -q drop class

./myRetrieval -k 50 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 50 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 100 -c 0.1 -o 1 -q final exam

./myRetrieval -k 100 -c 0.1 -o 2 -q tcp

./myRetrieval -k 100 -c 0.1 -o 3 -q computer system

./myRetrieval -k 100 -c 0.1 -o 4 -q network paper

./myRetrieval -k 100 -c 0.1 -o 5 -q spring break

./myRetrieval -k 100 -c 0.1 -o 6 -q software major

./myRetrieval -k 100 -c 0.1 -o 7 -q team work

./myRetrieval -k 100 -c 0.1 -o 8 -q group learn

./myRetrieval -k 100 -c 0.1 -o 9 -q public sever

./myRetrieval -k 100 -c 0.1 -o 10 -q america law

./myRetrieval -k 100 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 100 -c 0.1 -o 12 -q rsa

./myRetrieval -k 100 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 100 -c 0.1 -o 14 -q major

./myRetrieval -k 100 -c 0.1 -o 15 -q phd project

./myRetrieval -k 100 -c 0.1 -o 16 -q homework

./myRetrieval -k 100 -c 0.1 -o 17 -q fee due

./myRetrieval -k 100 -c 0.1 -o 18 -q drop class

./myRetrieval -k 100 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 100 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 150 -c 0.1 -o 1 -q final exam

./myRetrieval -k 150 -c 0.1 -o 2 -q tcp

./myRetrieval -k 150 -c 0.1 -o 3 -q computer system

./myRetrieval -k 150 -c 0.1 -o 4 -q network paper

./myRetrieval -k 150 -c 0.1 -o 5 -q spring break

./myRetrieval -k 150 -c 0.1 -o 6 -q software major

./myRetrieval -k 150 -c 0.1 -o 7 -q team work

./myRetrieval -k 150 -c 0.1 -o 8 -q group learn

./myRetrieval -k 150 -c 0.1 -o 9 -q public sever

./myRetrieval -k 150 -c 0.1 -o 10 -q america law

./myRetrieval -k 150 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 150 -c 0.1 -o 12 -q rsa

./myRetrieval -k 150 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 150 -c 0.1 -o 14 -q major

./myRetrieval -k 150 -c 0.1 -o 15 -q phd project

./myRetrieval -k 150 -c 0.1 -o 16 -q homework

./myRetrieval -k 150 -c 0.1 -o 17 -q fee due

./myRetrieval -k 150 -c 0.1 -o 18 -q drop class

./myRetrieval -k 150 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 150 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 200 -c 0.1 -o 1 -q final exam

./myRetrieval -k 200 -c 0.1 -o 2 -q tcp

./myRetrieval -k 200 -c 0.1 -o 3 -q computer system

./myRetrieval -k 200 -c 0.1 -o 4 -q network paper

./myRetrieval -k 200 -c 0.1 -o 5 -q spring break

./myRetrieval -k 200 -c 0.1 -o 6 -q software major

./myRetrieval -k 200 -c 0.1 -o 7 -q team work

./myRetrieval -k 200 -c 0.1 -o 8 -q group learn

./myRetrieval -k 200 -c 0.1 -o 9 -q public sever

./myRetrieval -k 200 -c 0.1 -o 10 -q america law

./myRetrieval -k 200 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 200 -c 0.1 -o 12 -q rsa

./myRetrieval -k 200 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 200 -c 0.1 -o 14 -q major

./myRetrieval -k 200 -c 0.1 -o 15 -q phd project

./myRetrieval -k 200 -c 0.1 -o 16 -q homework

./myRetrieval -k 200 -c 0.1 -o 17 -q fee due

./myRetrieval -k 200 -c 0.1 -o 18 -q drop class

./myRetrieval -k 200 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 200 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 250 -c 0.1 -o 1 -q final exam

./myRetrieval -k 250 -c 0.1 -o 2 -q tcp

./myRetrieval -k 250 -c 0.1 -o 3 -q computer system

./myRetrieval -k 250 -c 0.1 -o 4 -q network paper

./myRetrieval -k 250 -c 0.1 -o 5 -q spring break

./myRetrieval -k 250 -c 0.1 -o 6 -q software major

./myRetrieval -k 250 -c 0.1 -o 7 -q team work

./myRetrieval -k 250 -c 0.1 -o 8 -q group learn

./myRetrieval -k 250 -c 0.1 -o 9 -q public sever

./myRetrieval -k 250 -c 0.1 -o 10 -q america law

./myRetrieval -k 250 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 250 -c 0.1 -o 12 -q rsa

./myRetrieval -k 250 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 250 -c 0.1 -o 14 -q major

./myRetrieval -k 250 -c 0.1 -o 15 -q phd project

./myRetrieval -k 250 -c 0.1 -o 16 -q homework

./myRetrieval -k 250 -c 0.1 -o 17 -q fee due

./myRetrieval -k 250 -c 0.1 -o 18 -q drop class

./myRetrieval -k 250 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 250 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 300 -c 0.1 -o 1 -q final exam

./myRetrieval -k 300 -c 0.1 -o 2 -q tcp

./myRetrieval -k 300 -c 0.1 -o 3 -q computer system

./myRetrieval -k 300 -c 0.1 -o 4 -q network paper

./myRetrieval -k 300 -c 0.1 -o 5 -q spring break

./myRetrieval -k 300 -c 0.1 -o 6 -q software major

./myRetrieval -k 300 -c 0.1 -o 7 -q team work

./myRetrieval -k 300 -c 0.1 -o 8 -q group learn

./myRetrieval -k 300 -c 0.1 -o 9 -q public sever

./myRetrieval -k 300 -c 0.1 -o 10 -q america law

./myRetrieval -k 300 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 300 -c 0.1 -o 12 -q rsa

./myRetrieval -k 300 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 300 -c 0.1 -o 14 -q major

./myRetrieval -k 300 -c 0.1 -o 15 -q phd project

./myRetrieval -k 300 -c 0.1 -o 16 -q homework

./myRetrieval -k 300 -c 0.1 -o 17 -q fee due

./myRetrieval -k 300 -c 0.1 -o 18 -q drop class

./myRetrieval -k 300 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 300 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 350 -c 0.1 -o 1 -q final exam

./myRetrieval -k 350 -c 0.1 -o 2 -q tcp

./myRetrieval -k 350 -c 0.1 -o 3 -q computer system

./myRetrieval -k 350 -c 0.1 -o 4 -q network paper

./myRetrieval -k 350 -c 0.1 -o 5 -q spring break

./myRetrieval -k 350 -c 0.1 -o 6 -q software major

./myRetrieval -k 350 -c 0.1 -o 7 -q team work

./myRetrieval -k 350 -c 0.1 -o 8 -q group learn

./myRetrieval -k 350 -c 0.1 -o 9 -q public sever

./myRetrieval -k 350 -c 0.1 -o 10 -q america law

./myRetrieval -k 350 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 350 -c 0.1 -o 12 -q rsa

./myRetrieval -k 350 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 350 -c 0.1 -o 14 -q major

./myRetrieval -k 350 -c 0.1 -o 15 -q phd project

./myRetrieval -k 350 -c 0.1 -o 16 -q homework

./myRetrieval -k 350 -c 0.1 -o 17 -q fee due

./myRetrieval -k 350 -c 0.1 -o 18 -q drop class

./myRetrieval -k 350 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 350 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 400 -c 0.1 -o 1 -q final exam

./myRetrieval -k 400 -c 0.1 -o 2 -q tcp

./myRetrieval -k 400 -c 0.1 -o 3 -q computer system

./myRetrieval -k 400 -c 0.1 -o 4 -q network paper

./myRetrieval -k 400 -c 0.1 -o 5 -q spring break

./myRetrieval -k 400 -c 0.1 -o 6 -q software major

./myRetrieval -k 400 -c 0.1 -o 7 -q team work

./myRetrieval -k 400 -c 0.1 -o 8 -q group learn

./myRetrieval -k 400 -c 0.1 -o 9 -q public sever

./myRetrieval -k 400 -c 0.1 -o 10 -q america law

./myRetrieval -k 400 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 400 -c 0.1 -o 12 -q rsa

./myRetrieval -k 400 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 400 -c 0.1 -o 14 -q major

./myRetrieval -k 400 -c 0.1 -o 15 -q phd project

./myRetrieval -k 400 -c 0.1 -o 16 -q homework

./myRetrieval -k 400 -c 0.1 -o 17 -q fee due

./myRetrieval -k 400 -c 0.1 -o 18 -q drop class

./myRetrieval -k 400 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 400 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 450 -c 0.1 -o 1 -q final exam

./myRetrieval -k 450 -c 0.1 -o 2 -q tcp

./myRetrieval -k 450 -c 0.1 -o 3 -q computer system

./myRetrieval -k 450 -c 0.1 -o 4 -q network paper

./myRetrieval -k 450 -c 0.1 -o 5 -q spring break

./myRetrieval -k 450 -c 0.1 -o 6 -q software major

./myRetrieval -k 450 -c 0.1 -o 7 -q team work

./myRetrieval -k 450 -c 0.1 -o 8 -q group learn

./myRetrieval -k 450 -c 0.1 -o 9 -q public sever

./myRetrieval -k 450 -c 0.1 -o 10 -q america law

./myRetrieval -k 450 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 450 -c 0.1 -o 12 -q rsa

./myRetrieval -k 450 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 450 -c 0.1 -o 14 -q major

./myRetrieval -k 450 -c 0.1 -o 15 -q phd project

./myRetrieval -k 450 -c 0.1 -o 16 -q homework

./myRetrieval -k 450 -c 0.1 -o 17 -q fee due

./myRetrieval -k 450 -c 0.1 -o 18 -q drop class

./myRetrieval -k 450 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 450 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 500 -c 0.1 -o 1 -q final exam

./myRetrieval -k 500 -c 0.1 -o 2 -q tcp

./myRetrieval -k 500 -c 0.1 -o 3 -q computer system

./myRetrieval -k 500 -c 0.1 -o 4 -q network paper

./myRetrieval -k 500 -c 0.1 -o 5 -q spring break

./myRetrieval -k 500 -c 0.1 -o 6 -q software major

./myRetrieval -k 500 -c 0.1 -o 7 -q team work

./myRetrieval -k 500 -c 0.1 -o 8 -q group learn

./myRetrieval -k 500 -c 0.1 -o 9 -q public sever

./myRetrieval -k 500 -c 0.1 -o 10 -q america law

./myRetrieval -k 500 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 500 -c 0.1 -o 12 -q rsa

./myRetrieval -k 500 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 500 -c 0.1 -o 14 -q major

./myRetrieval -k 500 -c 0.1 -o 15 -q phd project

./myRetrieval -k 500 -c 0.1 -o 16 -q homework

./myRetrieval -k 500 -c 0.1 -o 17 -q fee due

./myRetrieval -k 500 -c 0.1 -o 18 -q drop class

./myRetrieval -k 500 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 500 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 550 -c 0.1 -o 1 -q final exam

./myRetrieval -k 550 -c 0.1 -o 2 -q tcp

./myRetrieval -k 550 -c 0.1 -o 3 -q computer system

./myRetrieval -k 550 -c 0.1 -o 4 -q network paper

./myRetrieval -k 550 -c 0.1 -o 5 -q spring break

./myRetrieval -k 550 -c 0.1 -o 6 -q software major

./myRetrieval -k 550 -c 0.1 -o 7 -q team work

./myRetrieval -k 550 -c 0.1 -o 8 -q group learn

./myRetrieval -k 550 -c 0.1 -o 9 -q public sever

./myRetrieval -k 550 -c 0.1 -o 10 -q america law

./myRetrieval -k 550 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 550 -c 0.1 -o 12 -q rsa

./myRetrieval -k 550 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 550 -c 0.1 -o 14 -q major

./myRetrieval -k 550 -c 0.1 -o 15 -q phd project

./myRetrieval -k 550 -c 0.1 -o 16 -q homework

./myRetrieval -k 550 -c 0.1 -o 17 -q fee due

./myRetrieval -k 550 -c 0.1 -o 18 -q drop class

./myRetrieval -k 550 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 550 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 600 -c 0.1 -o 1 -q final exam

./myRetrieval -k 600 -c 0.1 -o 2 -q tcp

./myRetrieval -k 600 -c 0.1 -o 3 -q computer system

./myRetrieval -k 600 -c 0.1 -o 4 -q network paper

./myRetrieval -k 600 -c 0.1 -o 5 -q spring break

./myRetrieval -k 600 -c 0.1 -o 6 -q software major

./myRetrieval -k 600 -c 0.1 -o 7 -q team work

./myRetrieval -k 600 -c 0.1 -o 8 -q group learn

./myRetrieval -k 600 -c 0.1 -o 9 -q public sever

./myRetrieval -k 600 -c 0.1 -o 10 -q america law

./myRetrieval -k 600 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 600 -c 0.1 -o 12 -q rsa

./myRetrieval -k 600 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 600 -c 0.1 -o 14 -q major

./myRetrieval -k 600 -c 0.1 -o 15 -q phd project

./myRetrieval -k 600 -c 0.1 -o 16 -q homework

./myRetrieval -k 600 -c 0.1 -o 17 -q fee due

./myRetrieval -k 600 -c 0.1 -o 18 -q drop class

./myRetrieval -k 600 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 600 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 650 -c 0.1 -o 1 -q final exam

./myRetrieval -k 650 -c 0.1 -o 2 -q tcp

./myRetrieval -k 650 -c 0.1 -o 3 -q computer system

./myRetrieval -k 650 -c 0.1 -o 4 -q network paper

./myRetrieval -k 650 -c 0.1 -o 5 -q spring break

./myRetrieval -k 650 -c 0.1 -o 6 -q software major

./myRetrieval -k 650 -c 0.1 -o 7 -q team work

./myRetrieval -k 650 -c 0.1 -o 8 -q group learn

./myRetrieval -k 650 -c 0.1 -o 9 -q public sever

./myRetrieval -k 650 -c 0.1 -o 10 -q america law

./myRetrieval -k 650 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 650 -c 0.1 -o 12 -q rsa

./myRetrieval -k 650 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 650 -c 0.1 -o 14 -q major

./myRetrieval -k 650 -c 0.1 -o 15 -q phd project

./myRetrieval -k 650 -c 0.1 -o 16 -q homework

./myRetrieval -k 650 -c 0.1 -o 17 -q fee due

./myRetrieval -k 650 -c 0.1 -o 18 -q drop class

./myRetrieval -k 650 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 650 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 700 -c 0.1 -o 1 -q final exam

./myRetrieval -k 700 -c 0.1 -o 2 -q tcp

./myRetrieval -k 700 -c 0.1 -o 3 -q computer system

./myRetrieval -k 700 -c 0.1 -o 4 -q network paper

./myRetrieval -k 700 -c 0.1 -o 5 -q spring break

./myRetrieval -k 700 -c 0.1 -o 6 -q software major

./myRetrieval -k 700 -c 0.1 -o 7 -q team work

./myRetrieval -k 700 -c 0.1 -o 8 -q group learn

./myRetrieval -k 700 -c 0.1 -o 9 -q public sever

./myRetrieval -k 700 -c 0.1 -o 10 -q america law

./myRetrieval -k 700 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 700 -c 0.1 -o 12 -q rsa

./myRetrieval -k 700 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 700 -c 0.1 -o 14 -q major

./myRetrieval -k 700 -c 0.1 -o 15 -q phd project

./myRetrieval -k 700 -c 0.1 -o 16 -q homework

./myRetrieval -k 700 -c 0.1 -o 17 -q fee due

./myRetrieval -k 700 -c 0.1 -o 18 -q drop class

./myRetrieval -k 700 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 700 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 750 -c 0.1 -o 1 -q final exam

./myRetrieval -k 750 -c 0.1 -o 2 -q tcp

./myRetrieval -k 750 -c 0.1 -o 3 -q computer system

./myRetrieval -k 750 -c 0.1 -o 4 -q network paper

./myRetrieval -k 750 -c 0.1 -o 5 -q spring break

./myRetrieval -k 750 -c 0.1 -o 6 -q software major

./myRetrieval -k 750 -c 0.1 -o 7 -q team work

./myRetrieval -k 750 -c 0.1 -o 8 -q group learn

./myRetrieval -k 750 -c 0.1 -o 9 -q public sever

./myRetrieval -k 750 -c 0.1 -o 10 -q america law

./myRetrieval -k 750 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 750 -c 0.1 -o 12 -q rsa

./myRetrieval -k 750 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 750 -c 0.1 -o 14 -q major

./myRetrieval -k 750 -c 0.1 -o 15 -q phd project

./myRetrieval -k 750 -c 0.1 -o 16 -q homework

./myRetrieval -k 750 -c 0.1 -o 17 -q fee due

./myRetrieval -k 750 -c 0.1 -o 18 -q drop class

./myRetrieval -k 750 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 750 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 800 -c 0.1 -o 1 -q final exam

./myRetrieval -k 800 -c 0.1 -o 2 -q tcp

./myRetrieval -k 800 -c 0.1 -o 3 -q computer system

./myRetrieval -k 800 -c 0.1 -o 4 -q network paper

./myRetrieval -k 800 -c 0.1 -o 5 -q spring break

./myRetrieval -k 800 -c 0.1 -o 6 -q software major

./myRetrieval -k 800 -c 0.1 -o 7 -q team work

./myRetrieval -k 800 -c 0.1 -o 8 -q group learn

./myRetrieval -k 800 -c 0.1 -o 9 -q public sever

./myRetrieval -k 800 -c 0.1 -o 10 -q america law

./myRetrieval -k 800 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 800 -c 0.1 -o 12 -q rsa

./myRetrieval -k 800 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 800 -c 0.1 -o 14 -q major

./myRetrieval -k 800 -c 0.1 -o 15 -q phd project

./myRetrieval -k 800 -c 0.1 -o 16 -q homework

./myRetrieval -k 800 -c 0.1 -o 17 -q fee due

./myRetrieval -k 800 -c 0.1 -o 18 -q drop class

./myRetrieval -k 800 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 800 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 850 -c 0.1 -o 1 -q final exam

./myRetrieval -k 850 -c 0.1 -o 2 -q tcp

./myRetrieval -k 850 -c 0.1 -o 3 -q computer system

./myRetrieval -k 850 -c 0.1 -o 4 -q network paper

./myRetrieval -k 850 -c 0.1 -o 5 -q spring break

./myRetrieval -k 850 -c 0.1 -o 6 -q software major

./myRetrieval -k 850 -c 0.1 -o 7 -q team work

./myRetrieval -k 850 -c 0.1 -o 8 -q group learn

./myRetrieval -k 850 -c 0.1 -o 9 -q public sever

./myRetrieval -k 850 -c 0.1 -o 10 -q america law

./myRetrieval -k 850 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 850 -c 0.1 -o 12 -q rsa

./myRetrieval -k 850 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 850 -c 0.1 -o 14 -q major

./myRetrieval -k 850 -c 0.1 -o 15 -q phd project

./myRetrieval -k 850 -c 0.1 -o 16 -q homework

./myRetrieval -k 850 -c 0.1 -o 17 -q fee due

./myRetrieval -k 850 -c 0.1 -o 18 -q drop class

./myRetrieval -k 850 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 850 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 900 -c 0.1 -o 1 -q final exam

./myRetrieval -k 900 -c 0.1 -o 2 -q tcp

./myRetrieval -k 900 -c 0.1 -o 3 -q computer system

./myRetrieval -k 900 -c 0.1 -o 4 -q network paper

./myRetrieval -k 900 -c 0.1 -o 5 -q spring break

./myRetrieval -k 900 -c 0.1 -o 6 -q software major

./myRetrieval -k 900 -c 0.1 -o 7 -q team work

./myRetrieval -k 900 -c 0.1 -o 8 -q group learn

./myRetrieval -k 900 -c 0.1 -o 9 -q public sever

./myRetrieval -k 900 -c 0.1 -o 10 -q america law

./myRetrieval -k 900 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 900 -c 0.1 -o 12 -q rsa

./myRetrieval -k 900 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 900 -c 0.1 -o 14 -q major

./myRetrieval -k 900 -c 0.1 -o 15 -q phd project

./myRetrieval -k 900 -c 0.1 -o 16 -q homework

./myRetrieval -k 900 -c 0.1 -o 17 -q fee due

./myRetrieval -k 900 -c 0.1 -o 18 -q drop class

./myRetrieval -k 900 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 900 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 950 -c 0.1 -o 1 -q final exam

./myRetrieval -k 950 -c 0.1 -o 2 -q tcp

./myRetrieval -k 950 -c 0.1 -o 3 -q computer system

./myRetrieval -k 950 -c 0.1 -o 4 -q network paper

./myRetrieval -k 950 -c 0.1 -o 5 -q spring break

./myRetrieval -k 950 -c 0.1 -o 6 -q software major

./myRetrieval -k 950 -c 0.1 -o 7 -q team work

./myRetrieval -k 950 -c 0.1 -o 8 -q group learn

./myRetrieval -k 950 -c 0.1 -o 9 -q public sever

./myRetrieval -k 950 -c 0.1 -o 10 -q america law

./myRetrieval -k 950 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 950 -c 0.1 -o 12 -q rsa

./myRetrieval -k 950 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 950 -c 0.1 -o 14 -q major

./myRetrieval -k 950 -c 0.1 -o 15 -q phd project

./myRetrieval -k 950 -c 0.1 -o 16 -q homework

./myRetrieval -k 950 -c 0.1 -o 17 -q fee due

./myRetrieval -k 950 -c 0.1 -o 18 -q drop class

./myRetrieval -k 950 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 950 -c 0.1 -o 20 -q midterm exam


./myRetrieval -k 1000 -c 0.1 -o 1 -q final exam

./myRetrieval -k 1000 -c 0.1 -o 2 -q tcp

./myRetrieval -k 1000 -c 0.1 -o 3 -q computer system

./myRetrieval -k 1000 -c 0.1 -o 4 -q network paper

./myRetrieval -k 1000 -c 0.1 -o 5 -q spring break

./myRetrieval -k 1000 -c 0.1 -o 6 -q software major

./myRetrieval -k 1000 -c 0.1 -o 7 -q team work

./myRetrieval -k 1000 -c 0.1 -o 8 -q group learn

./myRetrieval -k 1000 -c 0.1 -o 9 -q public sever

./myRetrieval -k 1000 -c 0.1 -o 10 -q america law

./myRetrieval -k 1000 -c 0.1 -o 11 -q borrow book

./myRetrieval -k 1000 -c 0.1 -o 12 -q rsa

./myRetrieval -k 1000 -c 0.1 -o 13 -q ssh key

./myRetrieval -k 1000 -c 0.1 -o 14 -q major

./myRetrieval -k 1000 -c 0.1 -o 15 -q phd project

./myRetrieval -k 1000 -c 0.1 -o 16 -q homework

./myRetrieval -k 1000 -c 0.1 -o 17 -q fee due

./myRetrieval -k 1000 -c 0.1 -o 18 -q drop class

./myRetrieval -k 1000 -c 0.1 -o 19 -q publish paper

./myRetrieval -k 1000 -c 0.1 -o 20 -q midterm exam


cd ../myEvaluation/

./myEvaluation 10

./myEvaluation 50

./myEvaluation 100

./myEvaluation 150

./myEvaluation 200

./myEvaluation 250

./myEvaluation 300

./myEvaluation 350

./myEvaluation 400

./myEvaluation 450

./myEvaluation 500

./myEvaluation 550

./myEvaluation 600

./myEvaluation 650

./myEvaluation 700

./myEvaluation 750

./myEvaluation 800

./myEvaluation 850

./myEvaluation 900

./myEvaluation 950

./myEvaluation 1000


echo "done!"

