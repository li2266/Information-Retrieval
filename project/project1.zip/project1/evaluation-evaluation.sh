#!/bin/bash
#evaluation

cd ../myRetrieval/




./myRetrieval -k 200 -c 0.1 -o 1 -q sever error

./myRetrieval -k 200 -c 0.1 -o 2 -q web develop

./myRetrieval -k 200 -c 0.1 -o 3 -q credit

./myRetrieval -k 200 -c 0.1 -o 4 -q research assistantship

./myRetrieval -k 200 -c 0.1 -o 5 -q teach assistantship

./myRetrieval -k 200 -c 0.1 -o 6 -q summer workshop

./myRetrieval -k 200 -c 0.1 -o 7 -q ieee paper

./myRetrieval -k 200 -c 0.1 -o 8 -q big problem

./myRetrieval -k 200 -c 0.1 -o 9 -q purdue rank

./myRetrieval -k 200 -c 0.1 -o 10 -q rsa public key

./myRetrieval -k 200 -c 0.1 -o 11 -q coursework

./myRetrieval -k 200 -c 0.1 -o 12 -q great prize

./myRetrieval -k 200 -c 0.1 -o 13 -q bad weather

./myRetrieval -k 200 -c 0.1 -o 14 -q open class

./myRetrieval -k 200 -c 0.1 -o 15 -q popular professor

./myRetrieval -k 200 -c 0.1 -o 16 -q error code

./myRetrieval -k 200 -c 0.1 -o 17 -q chairman

./myRetrieval -k 200 -c 0.1 -o 18 -q socket

./myRetrieval -k 200 -c 0.1 -o 19 -q stream

./myRetrieval -k 200 -c 0.1 -o 20 -q classroom night


./myRetrieval -k 250 -c 0.1 -o 1 -q sever error

./myRetrieval -k 250 -c 0.1 -o 2 -q web develop

./myRetrieval -k 250 -c 0.1 -o 3 -q credit

./myRetrieval -k 250 -c 0.1 -o 4 -q research assistantship

./myRetrieval -k 250 -c 0.1 -o 5 -q teach assistantship

./myRetrieval -k 250 -c 0.1 -o 6 -q summer workshop

./myRetrieval -k 250 -c 0.1 -o 7 -q ieee paper

./myRetrieval -k 250 -c 0.1 -o 8 -q big problem

./myRetrieval -k 250 -c 0.1 -o 9 -q purdue rank

./myRetrieval -k 250 -c 0.1 -o 10 -q rsa public key

./myRetrieval -k 250 -c 0.1 -o 11 -q coursework

./myRetrieval -k 250 -c 0.1 -o 12 -q great prize

./myRetrieval -k 250 -c 0.1 -o 13 -q bad weather

./myRetrieval -k 250 -c 0.1 -o 14 -q open class

./myRetrieval -k 250 -c 0.1 -o 15 -q popular professor

./myRetrieval -k 250 -c 0.1 -o 16 -q error code

./myRetrieval -k 250 -c 0.1 -o 17 -q chairman

./myRetrieval -k 250 -c 0.1 -o 18 -q socket

./myRetrieval -k 250 -c 0.1 -o 19 -q stream

./myRetrieval -k 250 -c 0.1 -o 20 -q classroom night


./myRetrieval -k 300 -c 0.1 -o 1 -q sever error

./myRetrieval -k 300 -c 0.1 -o 2 -q web develop

./myRetrieval -k 300 -c 0.1 -o 3 -q credit

./myRetrieval -k 300 -c 0.1 -o 4 -q research assistantship

./myRetrieval -k 300 -c 0.1 -o 5 -q teach assistantship

./myRetrieval -k 300 -c 0.1 -o 6 -q summer workshop

./myRetrieval -k 300 -c 0.1 -o 7 -q ieee paper

./myRetrieval -k 300 -c 0.1 -o 8 -q big problem

./myRetrieval -k 300 -c 0.1 -o 9 -q purdue rank

./myRetrieval -k 300 -c 0.1 -o 10 -q rsa public key

./myRetrieval -k 300 -c 0.1 -o 11 -q coursework

./myRetrieval -k 300 -c 0.1 -o 12 -q great prize

./myRetrieval -k 300 -c 0.1 -o 13 -q bad weather

./myRetrieval -k 300 -c 0.1 -o 14 -q open class

./myRetrieval -k 300 -c 0.1 -o 15 -q popular professor

./myRetrieval -k 300 -c 0.1 -o 16 -q error code

./myRetrieval -k 300 -c 0.1 -o 17 -q chairman

./myRetrieval -k 300 -c 0.1 -o 18 -q socket

./myRetrieval -k 300 -c 0.1 -o 19 -q stream

./myRetrieval -k 300 -c 0.1 -o 20 -q classroom night


./myRetrieval -k 350 -c 0.1 -o 1 -q sever error

./myRetrieval -k 350 -c 0.1 -o 2 -q web develop

./myRetrieval -k 350 -c 0.1 -o 3 -q credit

./myRetrieval -k 350 -c 0.1 -o 4 -q research assistantship

./myRetrieval -k 350 -c 0.1 -o 5 -q teach assistantship

./myRetrieval -k 350 -c 0.1 -o 6 -q summer workshop

./myRetrieval -k 350 -c 0.1 -o 7 -q ieee paper

./myRetrieval -k 350 -c 0.1 -o 8 -q big problem

./myRetrieval -k 350 -c 0.1 -o 9 -q purdue rank

./myRetrieval -k 350 -c 0.1 -o 10 -q rsa public key

./myRetrieval -k 350 -c 0.1 -o 11 -q coursework

./myRetrieval -k 350 -c 0.1 -o 12 -q great prize

./myRetrieval -k 350 -c 0.1 -o 13 -q bad weather

./myRetrieval -k 350 -c 0.1 -o 14 -q open class

./myRetrieval -k 350 -c 0.1 -o 15 -q popular professor

./myRetrieval -k 350 -c 0.1 -o 16 -q error code

./myRetrieval -k 350 -c 0.1 -o 17 -q chairman

./myRetrieval -k 350 -c 0.1 -o 18 -q socket

./myRetrieval -k 350 -c 0.1 -o 19 -q stream

./myRetrieval -k 350 -c 0.1 -o 20 -q classroom night

cd ../myEvaluation

./myEvaluation 200

./myEvaluation 250

./myEvaluation 300

./myEvaluation 350


echo "done!"

